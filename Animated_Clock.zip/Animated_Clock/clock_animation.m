% Final Project: Analog Clock
% Authors: Maxwell, Abdul, Salia, Isaac
% Class: Applied Programming

% Clear any vars and current figure and show it on top of screen
clear, clf, shg


% Setup drawing board for clock
radius = 10;
axis([-1.1 1.1 -1.1 1.1]);
axis square
axis off


% Used for 1-second markings
x = sin(2*pi*(1:60)/60);
y = cos(2*pi*(1:60)/60);

% Used for 5-second markings
sec_marks = 5:5:60;

% Draw border of clock with 1 second markings
line(x, y,...
    'LineStyle', 'none',...
    'Marker', '*',...
    'Color', 'black',...
    'MarkerSize', 3);
line(x(sec_marks), y(sec_marks),...
    'LineStyle', 'none',...
    'Marker', 'o',...
    'Color', 'r',...
    'MarkerSize', 10);

% Draw 5-second markings
for i = 1:length(sec_marks)
    x_pos = 1.1 * (x(sec_marks(i)) - 0.05);
    y_pos = 1.1 * (y(sec_marks(i)));
    text(x_pos, y_pos, num2str(i), 'fontsize', 16,'Color','b');
end

% Initialize the various time hands
hour = RainbowLine(20, radius*0.5);
min = RainbowLine(20, radius*0.35);
sec = RainbowLine(20, radius*0.2);

% Add a close button
close_btn = uicontrol('string', 'close', 'style', 'toggle');

% Increases drawing speed by using any available hardware for openGL
% acceleration. If not present, it'll default to using the software version
opengl hardware

while ishandle(close_btn) && ~get(close_btn, 'value')
    c = clock;
    
    % Draw the datetime text below the clock
    datetime_text = text(0, -1.3,...
        datestr(datetime('now')),...
        'FontSize', 16,...
        'HorizontalAlignment', 'center');

     Ashesi_text = text(0, -0.5, 'Ashesi⏰',...
        'FontSize', 18,'FontName','ZapfDingbats',...
        'HorizontalAlignment', 'center', 'Color','black');
    
    % Draw hours hand
    t = c(4)/12 + c(5)/(60 * 12) + c(6)/(60 * 60 * 12);
    hour.Draw([0 0.8*sin(2*pi*t)], [0 0.8*cos(2*pi*t)], [0 .3]);
    
    % Draw minutes hand
    t = c(5)/60 + c(6)/(60 * 60);
    min.Draw([0 sin(2*pi*t)], [0 cos(2*pi*t)], [.5 .8]);
    
    
    % Draw seconds hand, changing its color based on second
    t = floor(c(6)) / 60;
    sec.Draw([0 sin(2*pi*t)], [0 cos(2*pi*t)], t);
   
    % Force draw the figure to update hand position
    drawnow;
    
    % Delete the datetime text for redrawing it after current loop iteration
    delete(datetime_text);
end

% Close the figure once we're done
close(gcf);