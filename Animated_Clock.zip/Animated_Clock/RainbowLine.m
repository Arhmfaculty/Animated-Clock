classdef RainbowLine < handle
    properties
        X
        Y
        NumPoints
        LineWidth
        LineHandle
    end
    
    methods
        function obj = RainbowLine(NumPoints, LineWidth)
            % set colormap to HSV to properly draw the rainbow effect
            colormap(hsv);
            
            % by default, the color axis will scale based on the colors
            % that are drawn, based on the HSV scale from 0 to 1
            
            % ex. if the colors present are from 0 to 0.8, and all of a
            % sudden, a 0.9 appears, the color axis is automatically scaled
            % to 0 to 0.9, affecting all the other drawn colors
            clim('manual')
            
            % Number of points for linear spacing generation
            obj.NumPoints = NumPoints;
            obj.LineWidth = LineWidth;
            
            % Initialize the line handle
            obj.Draw([0 0], [0 0]);
        end
        
        function obj = Draw(obj, X, Y, CRange)
            % Compute the linspace for X and Y
            obj.X = linspace(X(1), X(2), obj.NumPoints);
            obj.Y = linspace(Y(1), Y(2), obj.NumPoints);
            
            XData = [obj.X; obj.X];
            YData = [obj.Y; obj.Y];
            
            % Create an array of zeros for the Z axis (no 3D drawing)
            z = zeros(size(obj.X));
            ZData = [z; z];
            
            if ~exist('CRange', 'var'); CRange = [0 1]; end
            if length(CRange) == 1; CRange = [CRange CRange]; end
            
            % The color range is from 0 to 1, via HSV, so make a series of
            % colored points from red to orange to yellow to green to cyan
            % to blue to purple back to red with the same amount of points
            col = linspace(CRange(1), CRange(2), obj.NumPoints);
            ColorData = [col; col];
            
            if ~ishandle(obj.LineHandle)
                % Create line handle if it doesn't exist
                obj.LineHandle = surface(...
                    XData, YData, ZData, ColorData,...
                    'FaceColor', 'none',...
                    'EdgeColor', 'interp',...
                    'LineWidth', obj.LineWidth);
            else
                % Update existing line handle with new data
                obj.LineHandle.XData = XData;
                obj.LineHandle.YData = YData;
                obj.LineHandle.CData = ColorData;
            end
        end
    end
end